<?php
    session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <title>Account Management</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <!-- BOOTSTRAP STYLING -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script> <!-- BOOTSTRAP STYLING -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <!-- BOOTSTRAP STYLING -->

    <link rel="stylesheet" href="style.css"> <!-- CSS file -->
    <link rel="shortcut icon" type="image/png" href="images/favicon.png" /> <!-- Favicon file -->
    <script src="script.js"></script>
</head>

<body>

    <!-- DATABASE CONNECTION IN CONFIG.PHP -->
    <?php
      include "config.php";

      // Check user login or not (THIS SITE ONLY ACCESSIBLE IF YOU LOGIN, GOING MANUALLY TO 'localhost/admin.php' WILL LEAD TO HOME PAGE IF NOT LOGGED IN)
      if(!(isset($_SESSION['username']))){
          header('Location: index.php');
      }


    ?>

    <!-- NAVIGATION BAR (TABS) -->
    <nav id="navbarid" class="navbar navbar-inverse">

        <div class="container-fluid">

            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand"><img src="images/logo.png" width="30" height="25"></a> <!-- LOGO AT THE LEFT -->
            </div>

            <div class="collapse navbar-collapse" id="myNavbar">
                <!-- ALL TABS STARTING FROM LEFT -->
                <ul class="nav navbar-nav">
                    <li><a href="index.php">Monday</a></li>
                    <li><a href="tue.php">Tuesday</a></li>
                    <li><a href="wed.php">Wednesday</a></li>
                    <li><a href="thu.php">Thursday</a></li>
                    <li><a href="fri.php">Friday</a></li>
                    <li><a href="sat.php">Saturday</a></li>
                    <li><a href="sun.php">Sunday</a></li>
                </ul>
                <!-- ALL TABS STARTING FROM RIGHT -->
                <ul class="nav navbar-nav navbar-right">

                    <?php 
                        if(!isset($_SESSION['username'])){
                            echo '<li><a href="login.php"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>';
                        }
                        else if($_SESSION['username'] == "admin"){ 
                            echo '<li><a href="admin.php"><span class="glyphicon glyphicon-log-in"></span> ADMIN PANEL</a></li>';
                            echo '<li><a href="logout.php">Logout</a></li>';
                        }
                        else if ($_SESSION['username'] == "manager"){
                            echo '<li class="active"><a href="manager.php"><span class="glyphicon glyphicon-log-in"></span> MANAGER PANEL</a></li>';
                            echo '<li><a href="logout.php">Logout</a></li>';
                        }
                        else {
                            echo '<li><a href="account.php"><span class="glyphicon glyphicon-log-in"></span> Manage Account (' .$_SESSION['username']. ')</a></li>';
                            echo '<li><a href="logout.php">Logout</a></li>';
                        }
                    ?>

                </ul>
            </div>

        </div>

    </nav>



    <div id="myCarousel" class="carousel slide" data-ride="carousel">

        <!-- Dot Indicators / each coresponds to one screen -->
        <ol class="carousel-indicators">
            <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
            <li data-target="#myCarousel" data-slide-to="1"></li>
            <li data-target="#myCarousel" data-slide-to="2"></li>
            <li data-target="#myCarousel" data-slide-to="3"></li>
            <li data-target="#myCarousel" data-slide-to="4"></li>
        </ol>


        <!-- Wrapper for slides (images) / slides are coressponding to featured movie of the week? -->
        <div class="carousel-inner" role="listbox">

            <!-- MONDAY -->
            <div class="item active">
                <img src="images/avengers.jpg" alt="Image for Monday">
            </div>
            <!-- TUESDAY -->
            <div class="item">
                <img src="images/action1.png" alt="Image for Tuesday">
            </div>
            <!-- WEDNESDAY -->
            <div class="item">
                <img src="images/action2.jpg" alt="Image for Wednesday">
            </div>
            <!-- THURSDAY -->
            <div class="item">
                <img src="images/action3.png" alt="Image for Thursday">
            </div>
            <!-- FRIDAY -->
            <div class="item">
                <img src="images/action4.jpg" alt="Image for Friday">
            </div>

        </div>


        <!-- Left and right arrows for sliding screens -->
        <a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
            <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
        </a>
        <a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
            <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
        </a>

    </div>

    <!-- ALL THE CONTENT IN THE MIDDLE -->
    <div class="container-main">
        <div class="container-hello">




            <h3>BOOKED RESERVATIONS: </h3><br>

            <?php

                $headerForTable = "<center><table border=1><th>Booking ID</th><th>Time & Date</th><th>Movie Title</th><th>Screen Number</th><th>Number of seats</th><th>Cost</th>";

                $loggedUser = $_SESSION['username'];

                $sqlStatm = "SELECT bookingID, noOfSeats, cost, date, time, screenNo, name FROM booking, screening, film WHERE username = '$loggedUser' AND screening.filmID = film.filmID AND booking.screeningID = screening.screeningID";
                $result = mysqli_query($conn, $sqlStatm);
                $numOfRows = mysqli_num_rows($result);

                if ($numOfRows > 0) 
                {
                    echo $headerForTable;

                    for ($i=0; $i < $numOfRows; $i++) 
                    {
                        $row = mysqli_fetch_array($result);
                        echo "<tr><td><b>" . $row["bookingID"]. "</b></td><td><b>" . date('H:i', strtotime($row["time"])). "</b><br>" . date('l, d-m', strtotime($row["date"])) . "</td><td><b>" . $row["name"]. "</b></td><td>" . $row["screenNo"]. "</td><td>" . $row["noOfSeats"]. 
                            "</td><td>" . $row["cost"]. "</td><tr>";
                    }
                    echo "</table></center>";

                }
                else{
                    echo "<h1>You currently do not have any bookings.</h2>";
                }
                

            ?>

        </div>

    </div>

    <!-- FOOTER INCLUDED FROM SEPARATE FILE -->
    <footer class="container-fluid text-center">
        <?php 
                mysqli_close($conn); //CLOSING DB DONNECTION AT THE END OF THE PAGE
                include 'footer.html'; 
            ?>
    </footer>

</body>

</html>