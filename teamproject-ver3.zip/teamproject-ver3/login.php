<?php
    session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <title>Login Page</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="style.css">
    <link rel="shortcut icon" type="image/png" href="images/favicon.png" />

</head>

<body class="login">

    <?php

        include "config.php";

        if(isset($_POST['but_submit'])){

            $uname = mysqli_real_escape_string($conn,$_POST['txt_uname']); //get name and login entered
            $password = mysqli_real_escape_string($conn,$_POST['txt_pwd']);

            if ($uname != "" && $password != ""){ //if not empty strings

                $sql_query = "select count(*) as cntUser from credentials where username='".$uname."' and password='".$password."'";
                $result = mysqli_query($conn,$sql_query);
                $row = mysqli_fetch_array($result);

                $count = $row['cntUser'];

                if($count > 0){

                    if($uname == 'admin'){
                        $_SESSION['username'] = $uname;
                        $_SESSION['logged'] = true;
                        header('Location: admin.php'); //redirects properly to admin page if admin credential entered
                    }
                    else if($uname == 'manager'){
                        $_SESSION['username'] = $uname;
                        $_SESSION['logged'] = true;
                        header('Location: manager.php'); //same for manager page
                    }
                    else {
                        $_SESSION['username'] = $uname;
                        $_SESSION['logged'] = true;
                        header('Location: account.php'); //for other users redirect to their account
                    }
                }
                
                else{
                    echo "<script type='text/javascript'>alert('Invalid username and/or password');</script>";
                }

            }

        } 
    ?>


    <nav class="navbar navbar-inverse">

        <div class="container-fluid">

            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand"><img src="images/logo.png" width="30" height="25"></a>
            </div>

            <div class="collapse navbar-collapse" id="myNavbar">
                <ul class="nav navbar-nav">
                    <li><a href="index.php">Monday</a></li>
                    <li><a href="tue.php">Tuesday</a></li>
                    <li><a href="wed.php">Wednesday</a></li>
                    <li><a href="thu.php">Thursday</a></li>
                    <li><a href="fri.php">Friday</a></li>
                    <li><a href="sat.php">Saturday</a></li>
                    <li><a href="sun.php">Sunday</a></li>
                </ul>
                <ul class="nav navbar-nav navbar-right">

                    <?php 
                        if(!isset($_SESSION['username'])){
                            echo '<li><a href="login.php"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>';
                        }
                        else if($_SESSION['username'] == "admin"){ 
                            echo '<li><a href="admin.php"><span class="glyphicon glyphicon-log-in"></span> ADMIN PANEL</a></li>';
                            echo '<li><a href="logout.php">Logout</a></li>';
                        }
                        else if ($_SESSION['username'] == "manager"){
                            echo '<li class="active"><a href="manager.php"><span class="glyphicon glyphicon-log-in"></span> MANAGER PANEL</a></li>';
                            echo '<li><a href="logout.php">Logout</a></li>';
                        }
                        else {
                            echo '<li><a href="account.php"><span class="glyphicon glyphicon-log-in"></span> Manage Account (' .$_SESSION['username']. ')</a></li>';
                            echo '<li><a href="logout.php">Logout</a></li>';
                        }
                    ?>

                </ul>

            </div>

        </div>

    </nav>

    <div class="containerLogin">
        <form method="post" action="">
            <div id="div_login">
                <h1>Login</h1>
                <p>admin / admin123<br>
                    manager / manager123</p>
                <div>
                    <input type="text" class="textbox" id="txt_uname" name="txt_uname" placeholder="Username" />
                </div><br>
                <div>
                    <input type="password" class="textbox" id="txt_pwd" name="txt_pwd" placeholder="Password" />
                </div><br>
                <div>
                    <input type="submit" value="Login" name="but_submit" id="but_submit" />
                </div><br>
            </div>
        </form>

        <br><br>

        <h3>Don't have an account?</h3>
        <button id="regBut" onClick="window.location.href='register.php'">Register</button>
    </div>

    <!-- FOOTER INCLUDED FROM SEPARATE FILE -->
    <footer class="container-fluid text-center">
        <?php 
                mysqli_close($conn); //CLOSING DB DONNECTION AT THE END OF THE PAGE
                include 'footer.html'; 
            ?>
    </footer>

</body>

</html>