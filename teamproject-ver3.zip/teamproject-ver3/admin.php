<?php
    session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <title>ADMIN BACK-END</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>


    <link rel="stylesheet" href="style.css">
    <link rel="shortcut icon" type="image/png" href="images/favicon.png" />
    <script src="script.js"></script>
    <style>
    #buttonsDiv {
        width: 100%;
        display: flex;
        margin: auto;
        justify-content: space-between;
    }
    </style>

</head>

<body class="login">

    <?php

      include "config.php";

      // Check user login or not (THIS SITE ONLY ACCESSIBLE IF YOU LOGIN, GOING MANUALLY TO 'localhost/admin.php' WILL LEAD TO HOME PAGE IF NOT LOGGED IN)
      if($_SESSION['username'] != "admin"){
          header('Location: index.php');
      }

    ?>



    <!-- NAVIGATION BAR (TABS) -->
    <nav class="navbar navbar-inverse">

        <div class="container-fluid">

            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand"><img src="images/logo.png" width="30" height="25"></a> <!-- LOGO AT THE LEFT -->
            </div>

            <div class="collapse navbar-collapse" id="myNavbar">
                <!-- ALL TABS STARTING FROM LEFT -->
                <ul class="nav navbar-nav">
                    <li><a href="index.php">Monday</a></li>
                    <li><a href="tue.php">Tuesday</a></li>
                    <li><a href="wed.php">Wednesday</a></li>
                    <li><a href="thu.php">Thursday</a></li>
                    <li><a href="fri.php">Friday</a></li>
                    <li><a href="sat.php">Saturday</a></li>
                    <li><a href="sun.php">Sunday</a></li>
                </ul>
                <!-- ALL TABS STARTING FROM RIGHT -->
                <ul class="nav navbar-nav navbar-right">

                    <?php 
                        if(!isset($_SESSION['username'])){
                            echo '<li><a href="login.php"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>';
                        }
                        else if($_SESSION['username'] == "admin"){ 
                            echo '<li><a href="admin.php"><span class="glyphicon glyphicon-log-in"></span> ADMIN PANEL</a></li>';
                            echo '<li><a href="logout.php">Logout</a></li>';
                        }
                        else if ($_SESSION['username'] == "manager"){
                            echo '<li class="active"><a href="manager.php"><span class="glyphicon glyphicon-log-in"></span> MANAGER PANEL</a></li>';
                            echo '<li><a href="logout.php">Logout</a></li>';
                        }
                        else {
                            echo '<li><a href="account.php"><span class="glyphicon glyphicon-log-in"></span> Manage Account (' .$_SESSION['username']. ')</a></li>';
                            echo '<li><a href="logout.php">Logout</a></li>';
                        }
                    ?>

                </ul>
            </div>

        </div>

    </nav>



    <div class="container text-center">

        <h3>Select one of the movies to activate edit or delete correctly</h3>
        <div id='buttonsDiv'>

            <form action="addMovieMenu.php" method="post">
                <a href="#"> <input class="buttons" type="submit" value="Add"></input>
            </form></a>

            <form action="editMovieMenu.php" method="post">
                <a href="#"><input class="buttons" type="submit" value="Edit"></input>
            </form></a>

            <a href="#"><input class="buttons" type="button" value="Record Film Details"></input></a>

        </div>
        <br>

        <div class="row">

            <form class="container-table" action="admin.php" method="post">

                <?php 

                    if( isset( $_POST["delMovie"] ) ){
                        $filmID = $_POST["movie"];
                        $myQuery = "DELETE FROM film WHERE filmID = '$filmID'"; //if the button was pressed from a partiuclar day, it will remove the movie from DB
                        $result = mysqli_query($conn, $myQuery);
                    }

                    echo "<center><table border=1><th>Select</th><th>Film ID</th><th>Name</th><th>Age Rating</th><th>Length</th>";

                    $sqlStatm = "SELECT filmID, name,ageRating, length, genre, description FROM film ORDER BY filmID";
                    $result = mysqli_query($conn, $sqlStatm);
                    $numOfRows = mysqli_num_rows($result);

                    if ($numOfRows > 0) {
                        for ($j=0; $j < $numOfRows; $j++) {
                            $row = mysqli_fetch_array($result);
                            echo "<tr><td><input type='radio' id='" . $row["filmID"]. "' name='movie' value='" . $row["filmID"]. "'></td><td>" . $row["filmID"]. "</td><td><b>" . $row["name"]. "</b></td><td>" . $row["ageRating"]. "</td><td>" . $row["length"]."</td><tr>";
                        }
                        echo "</table></center>";
                    }
                    else {
                        echo "zero result";
                    }

                    ?>

                <input class='buttons' type='submit' name='delMovie' value='Delete Movie'>
            </form>
        </div>


    </div><br>



    <!-- FOOTER INCLUDED FROM SEPARATE FILE -->
    <footer class="container-fluid text-center">
        <?php 
                mysqli_close($conn); //CLOSING DB DONNECTION AT THE END OF THE PAGE
                include 'footer.html'; 
            ?>
    </footer>

</body>

</html>