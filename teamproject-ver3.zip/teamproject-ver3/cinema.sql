-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 15, 2021 at 12:08 PM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 8.0.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cinema`
--

-- --------------------------------------------------------

--
-- Table structure for table `booking`
--

CREATE TABLE `booking` (
  `bookingID` int(11) NOT NULL,
  `noOfSeats` int(11) NOT NULL,
  `cost` decimal(10,0) NOT NULL,
  `customerID` int(11) NOT NULL,
  `screeningID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `credentials`
--

CREATE TABLE `credentials` (
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `credentials`
--

INSERT INTO `credentials` (`username`, `password`) VALUES
('admin', 'admin123'),
('manager', 'manager123');

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `film`
--

CREATE TABLE `film` (
  `filmID` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `ageRating` varchar(5) NOT NULL,
  `length` int(3) NOT NULL,
  `genre` varchar(100) NOT NULL,
  `description` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `film`
--

INSERT INTO `film` (`filmID`, `name`, `ageRating`, `length`, `genre`, `description`) VALUES
(1, 'Avengers: Endgame', '15A', 139, 'Action', 'After Thanos, an intergalactic warlord, disintegrates half of the universe, the Avengers must reunite and assemble again to reinvigorate their trounced allies and restore balance.'),
(2, 'Forrest Gump', '12', 142, 'Drama', 'Forrest, a man with low IQ, recounts the early years of his life when he found himself in the middle of key historical events. All he wants now is to be reunited with his childhood sweetheart, Jenn'),
(3, 'Shawshank Redemption', '15', 142, 'Drama', 'Andy Dufresne, a successful banker, is arrested for the murders of his wife and her lover, and is sentenced to life imprisonment at the Shawshank prison. He becomes the most unconventional prisoner.'),
(4, 'Pulp Fiction', '18', 160, 'Crime', 'In the realm of underworld, a series of incidents intertwines the lives of two Los Angeles mobsters, a gangster\'s wife, a boxer and two small-time criminals.'),
(5, 'Joker', '18', 122, 'Crime', 'Arthur Fleck, a party clown, leads an impoverished life with his ailing mother. However, when society shuns him and brands him as a freak, he decides to embrace the life of crime and chaos'),
(6, 'Shrek 2', 'PG', 105, 'Comedy', 'When Shrek and Fiona return from their honeymoon, her parents, the rulers of Far Far Away, invite them over. But as the king does not like Shrek, he enlists a fairy to keep him away from his daughter.'),
(7, 'Cars', 'PG', 117, 'Family', 'Lightning McQueen, a racing car, learns a hard lesson in life when he damages a lot of property in Radiator Springs. His task is to repair the damage done before he can get back on the road.'),
(8, 'The Revenant', '18', 156, 'Western', 'Hugh Glass, a legendary frontiersman, is severely injured in a bear attack and is abandoned by his hunting crew. He uses his skills to survive and take revenge on his companion who betrayed him.'),
(9, 'Step Brother', '15', 110, 'Comedy', 'Will Ferrell and John C.Reilly'),
(10, 'Monsters Inc.', 'PG', 110, 'Family', 'Mike Wazowski and Sully in Monsters Inc.'),
(11, 'Star Wars: Revenge of the Sith', '15A', 140, 'Action', 'Anakin Skywalker goes rogue'),
(12, 'Broken Law', '16', 130, 'Action', 'Two brothers, who is a guard and the other is a criminal'),
(13, 'The Field', '12', 110, 'Drama', 'Bull McCabe goes mad in a field'),
(14, 'Iron Man', '12', 110, 'Action', 'Tony Stark, Millionaire is Iron Man.'),
(15, 'Lassie', 'PG', 98, 'Drama', ' family in financial crisis is forced to sell Lassie, their beloved dog. Hundreds of miles away from her true family, Lassie escapes and sets out on a journey home.'),
(16, 'Scooby Doo', 'PG', 100, 'Family', 'Scooby Doo group goes to weird island to fight evil Mr.Bean.');

-- --------------------------------------------------------

--
-- Table structure for table `screening`
--

CREATE TABLE `screening` (
  `screeningID` int(11) NOT NULL,
  `screenNo` int(11) NOT NULL,
  `time` time NOT NULL,
  `date` date DEFAULT NULL,
  `capacity` int(11) NOT NULL,
  `price` decimal(10,0) NOT NULL,
  `filmID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `screening`
--

INSERT INTO `screening` (`screeningID`, `screenNo`, `time`, `date`, `capacity`, `price`, `filmID`) VALUES
(1, 1, '11:30:00', '2021-03-22', 120, '5', 1),
(2, 4, '11:30:00', '2021-03-22', 120, '5', 8),
(3, 2, '14:30:00', '2021-03-22', 120, '5', 2),
(4, 3, '14:30:00', '2021-03-22', 120, '5', 7),
(5, 3, '17:30:00', '2021-03-22', 120, '5', 3),
(6, 2, '17:30:00', '2021-03-22', 120, '5', 6),
(7, 4, '20:30:00', '2021-03-22', 120, '5', 4),
(8, 1, '20:30:00', '2021-03-22', 120, '5', 5),
(9, 1, '11:30:00', '2021-03-23', 120, '5', 8),
(10, 4, '11:30:00', '2021-03-23', 120, '5', 7),
(11, 2, '14:30:00', '2021-03-23', 120, '5', 6),
(12, 3, '14:30:00', '2021-03-23', 120, '5', 5),
(13, 3, '17:30:00', '2021-03-23', 120, '5', 4),
(14, 2, '17:30:00', '2021-03-23', 120, '5', 3),
(15, 4, '20:30:00', '2021-03-23', 120, '5', 2),
(16, 1, '20:30:00', '2021-03-23', 120, '5', 1),
(17, 1, '11:30:00', '2021-03-24', 120, '5', 1),
(18, 4, '11:30:00', '2021-03-24', 120, '5', 8),
(19, 2, '14:30:00', '2021-03-24', 120, '5', 2),
(20, 3, '14:30:00', '2021-03-24', 120, '5', 7),
(21, 3, '17:30:00', '2021-03-24', 120, '5', 3),
(22, 2, '17:30:00', '2021-03-24', 120, '5', 6),
(23, 4, '20:30:00', '2021-03-24', 120, '5', 4),
(24, 1, '20:30:00', '2021-03-24', 120, '5', 5),
(25, 1, '11:30:00', '2021-03-25', 120, '5', 1),
(26, 4, '11:30:00', '2021-03-25', 120, '5', 3),
(27, 2, '14:30:00', '2021-03-25', 120, '5', 5),
(28, 3, '14:30:00', '2021-03-25', 120, '5', 7),
(29, 3, '17:30:00', '2021-03-25', 120, '5', 9),
(30, 2, '17:30:00', '2021-03-25', 120, '5', 11),
(31, 4, '20:30:00', '2021-03-25', 120, '5', 13),
(32, 1, '20:30:00', '2021-03-25', 120, '5', 15),
(33, 1, '11:30:00', '2021-03-26', 120, '5', 2),
(34, 4, '11:30:00', '2021-03-26', 120, '5', 4),
(35, 2, '14:30:00', '2021-03-26', 120, '5', 6),
(36, 3, '14:30:00', '2021-03-26', 120, '5', 8),
(37, 3, '17:30:00', '2021-03-26', 120, '5', 10),
(38, 2, '17:30:00', '2021-03-26', 120, '5', 12),
(39, 4, '20:30:00', '2021-03-26', 120, '5', 14),
(40, 1, '20:30:00', '2021-03-26', 120, '5', 16),
(41, 1, '11:30:00', '2021-03-27', 120, '5', 16),
(42, 4, '11:30:00', '2021-03-27', 120, '5', 12),
(43, 2, '14:30:00', '2021-03-27', 120, '5', 14),
(44, 3, '14:30:00', '2021-03-27', 120, '5', 13),
(45, 3, '17:30:00', '2021-03-27', 120, '5', 1),
(46, 2, '17:30:00', '2021-03-27', 120, '5', 2),
(47, 4, '20:30:00', '2021-03-27', 120, '5', 3),
(48, 1, '20:30:00', '2021-03-27', 120, '5', 4),
(49, 1, '11:30:00', '2021-03-28', 120, '5', 5),
(50, 4, '11:30:00', '2021-03-28', 120, '5', 6),
(51, 2, '14:30:00', '2021-03-28', 120, '5', 7),
(52, 3, '14:30:00', '2021-03-28', 120, '5', 8),
(53, 3, '17:30:00', '2021-03-28', 120, '5', 9),
(54, 2, '17:30:00', '2021-03-28', 120, '5', 10),
(55, 4, '20:30:00', '2021-03-28', 120, '5', 11),
(56, 1, '20:30:00', '2021-03-28', 120, '5', 12);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `booking`
--
ALTER TABLE `booking`
  ADD PRIMARY KEY (`bookingID`),
  ADD UNIQUE KEY `customerID` (`customerID`,`screeningID`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`email`);

--
-- Indexes for table `film`
--
ALTER TABLE `film`
  ADD PRIMARY KEY (`filmID`);

--
-- Indexes for table `screening`
--
ALTER TABLE `screening`
  ADD PRIMARY KEY (`screeningID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `booking`
--
ALTER TABLE `booking`
  MODIFY `bookingID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `film`
--
ALTER TABLE `film`
  MODIFY `filmID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `screening`
--
ALTER TABLE `screening`
  MODIFY `screeningID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=57;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;