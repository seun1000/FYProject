<?php
    session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <title>Cinema Team Project</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <!-- BOOTSTRAP STYLING -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script> <!-- BOOTSTRAP STYLING -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <!-- BOOTSTRAP STYLING -->

    <link rel="stylesheet" href="style.css"> <!-- CSS file -->
    <link rel="shortcut icon" type="image/png" href="images/favicon.png" /> <!-- Favicon file -->
    <script src="script.js"></script>

</head>

<body>

    <!-- DATABASE CONNECTION IN CONFIG.PHP -->
    <?php
      include "config.php";
    ?>

    <!-- NAVIGATION BAR (TABS) -->
    <nav id="navbarid" class="navbar navbar-inverse">

        <div class="container-fluid">

            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand"><img src="images/logo.png" width="30" height="25"></a> <!-- LOGO AT THE LEFT -->
            </div>

            <div class="collapse navbar-collapse" id="myNavbar">
                <!-- ALL TABS STARTING FROM LEFT -->
                <ul class="nav navbar-nav">
                    <li><a href="index.php">Monday</a></li>
                    <li><a href="tue.php">Tuesday</a></li>
                    <li><a href="wed.php">Wednesday</a></li>
                    <li><a href="thu.php">Thursday</a></li>
                    <li><a href="fri.php">Friday</a></li>
                    <li class="active"><a href="sat.php">Saturday</a></li>
                    <li><a href="sun.php">Sunday</a></li>
                </ul>
                <!-- ALL TABS STARTING FROM RIGHT -->
                <ul class="nav navbar-nav navbar-right">

                    <?php 
                        if(!isset($_SESSION['username'])){
                            echo '<li><a href="login.php"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>';
                        }
                        else if($_SESSION['username'] == "admin"){ 
                            echo '<li><a href="admin.php"><span class="glyphicon glyphicon-log-in"></span> ADMIN PANEL</a></li>';
                            echo '<li><a href="logout.php">Logout</a></li>';
                        }
                        else if ($_SESSION['username'] == "manager"){
                            echo '<li class="active"><a href="manager.php"><span class="glyphicon glyphicon-log-in"></span> MANAGER PANEL</a></li>';
                            echo '<li><a href="logout.php">Logout</a></li>';
                        }
                        else {
                            echo '<li><a href="account.php"><span class="glyphicon glyphicon-log-in"></span> Manage Account (' .$_SESSION['username']. ')</a></li>';
                            echo '<li><a href="logout.php">Logout</a></li>';
                        }
                    ?>

                </ul>
            </div>

        </div>

    </nav>

    <div id="myCarousel" class="carousel slide" data-ride="carousel">

        <!-- Dot Indicators / each coresponds to one screen -->
        <ol class="carousel-indicators">
            <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
            <li data-target="#myCarousel" data-slide-to="1"></li>
            <li data-target="#myCarousel" data-slide-to="2"></li>
            <li data-target="#myCarousel" data-slide-to="3"></li>
            <li data-target="#myCarousel" data-slide-to="4"></li>
        </ol>


        <!-- Wrapper for slides (images) / slides are coressponding to featured movie of the week? -->
        <div class="carousel-inner" role="listbox">

            <!-- MONDAY -->
            <div class="item">
                <img src="images/horror1.jpg" alt="Image for Monday">
            </div>
            <!-- TUESDAY -->
            <div class="item">
                <img src="images/horror2.jpg" alt="Image for Tuesday">
            </div>
            <!-- WEDNESDAY -->
            <div class="item">
                <img src="images/horror3.jpg" alt="Image for Wednesday">
            </div>
            <!-- THURSDAY -->
            <div class="item">
                <img src="images/horror4.jpg" alt="Image for Thursday">
            </div>
            <!-- FRIDAY -->
            <div class="item active">
                <img src="images/horror5.jpg" alt="Image for Friday">
            </div>

        </div>


        <!-- Left and right arrows for sliding screens -->
        <a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
            <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
        </a>
        <a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
            <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
        </a>

    </div>

    <!-- ALL THE CONTENT IN THE MIDDLE -->
    <div class="container-main">
        <div class="container-hello">
            <!-- START OF FORM -->
            <form id='movieM' class="container-table" action="/teamproject-recent/book.php" method="POST">

                <?php 
                $headerForTable = "<center><table border=1><th>Select</th><th>Time & Date</th><th>Movie Title</th><th>Age Rating</th><th>Length (mins)</th><th>Genre</th><th>Description</th><th>Seats Left</th><th>Price</th>";

                $sqlStatm = "SELECT date FROM screening WHERE date='2021-03-27'";
                $result = mysqli_query($conn, $sqlStatm);
                $numOfRows = mysqli_num_rows($result);
                
                if ($numOfRows > 0){
                    $row = mysqli_fetch_assoc($result);
                    echo "<h3>Movie Schedule for Saturday, " . $row["date"] ."</h3><br>";
                }
                else 
                {
                    echo "zero result";
                } 
                

                //TABLE FROM DATABASE
                    $screens = [1, 2, 3, 4];
                    for ($i=0; $i < 4; $i++) { 
                        
                        
                        
                        echo "<h2>SCREEN".$screens[$i]."</h2>";
                        echo $headerForTable;
                        $sqlStatm = "SELECT screeningID, screenNo, time, capacity, price, name, ageRating, length, genre, description, date FROM screening, film WHERE screenNo = ".$screens[$i]." AND date = '2021-03-27' AND screening.filmID = film.filmID ORDER BY time";
                        $result = mysqli_query($conn, $sqlStatm);
                        $numOfRows = mysqli_num_rows($result);
                        
                        if ($numOfRows > 0) 
                        {

                            for ($j=0; $j < $numOfRows; $j++) 
                            {
                                $row = mysqli_fetch_array($result);
                                echo "<tr><td><input type='radio' id='" . $row["screeningID"]. "' name='movie' value='" . $row["screeningID"]. "' required ". (($row["capacity"] > 0) ? '' : 'disabled') ."></td><td><b>" . date('H:i', strtotime($row["time"])). "</b><br>" . date('l, d-m', strtotime($row["date"])) . "</td><td><b>" . $row["name"]. "</b></td><td>" . $row["ageRating"]. "</td><td>" . $row["length"]. 
                                    "</td><td>" . $row["genre"]. "</td><td>" . $row["description"]. "</td><td>" . ($row["capacity"] > 0 ? $row["capacity"] : '<b>SOLD OUT</b>'). "</td><td>Adults: &euro;" .$row["price"] * 1.6 . "<br>Kids: &euro;" . $row["price"]. "</td><tr>";
                            }
                            echo "</table></center>";
                        } 
                        else 
                        {
                            echo "zero result";
                        } 

                }



                    ?>

        </div>

        <br>

        <div>
            <input class="buttons" type="submit" value="Book Ticket" name="submit-btn"></button>
            <input class="buttons" type="button" value="View Trailer" onclick="displayTrailer()"></input>
            </form>
            <!--END OF FORM -->
        </div>

    </div>


    <!-- FOOTER INCLUDED FROM SEPARATE FILE -->
    <footer class="container-fluid text-center">
        <?php 
                mysqli_close($conn); //CLOSING DB DONNECTION AT THE END OF THE PAGE
                include 'footer.html'; 
            ?>
    </footer>

</body>

</html>