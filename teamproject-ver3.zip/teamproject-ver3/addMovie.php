<?php
    session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>


    <link rel="stylesheet" href="style.css">
    <link rel="shortcut icon" type="image/png" href="images/favicon.png" />
    <style>
    body {
        color: #404040;
        background: #0ca3d2;
    }
    </style>
</head>

<body>
    <?php
        $filmID = $_POST["filmID"];
        $name = $_POST["name"];
        $ageRating = $_POST["ageRating"];
        $length = $_POST["length"];
        $genre = $_POST["genre"];
        $description = $_POST["description"];


        include "config.php";



        $myQuery = "INSERT INTO film VALUES ('$filmID', '$name', '$ageRating', '$length', '$genre', '$description')";
        echo $myQuery;
    
        $result = mysqli_query($conn, $myQuery);
        if($result) {
            echo 'OK record inserted';
        } else {
            echo 'No insertion made';
        }

    ?>

    <!-- BACK BUTTON -->
    <button onclick="goBack()">Go Back</button>
    <script>
    function goBack() {
        window.history.back();
    }
    </script>
    <!-- BACK BUTTON -->

    <footer class="container-fluid text-center">
        <?php 
                mysqli_close($conn); //CLOSING DB DONNECTION AT THE END OF THE PAGE
                include 'footer.html'; 
            ?>
    </footer>

</body>

</html>