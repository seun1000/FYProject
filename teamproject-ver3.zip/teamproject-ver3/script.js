// function totalCost() {
//     var arr = document.getElementsByName('adults');
//     var arr2 = document.getElementsByName('kids');
//     var totAdult = 0;
//     var totKid = 0;
//     var counterA = 0;
//     var counterK = 0;
//     for (var i = 0; i < arr.length; i++) {
//         if (parseInt(arr[i].value))

//             totAdult += parseInt(arr[i].value);
//         totAdult *= 8;
//         counterK += parseInt(arr[i].value);
//     }

//     for (var i = 0; i < arr2.length; i++) {
//         if (parseInt(arr2[i].value))
//             counterA += parseInt(arr2[i].value);
//         totKid += parseInt(arr2[i].value);
//         totKid *= 5;
//     }
//     document.getElementById('total').value = totAdult + totKid;
//     document.getElementById('noOfSeats').value = counterA + counterK;
// }
var trailer = [
    "https://www.youtube.com/watch?v=TcMBFSGVi1c",//avengers end game
    "https://www.youtube.com/watch?v=uPIEn0M8su0",//forrest gump
    "https://www.youtube.com/watch?v=6hB3S9bIaco",//shawshank
    "https://www.youtube.com/watch?v=s7EdQ4FqbhY",//pulp fiction
    "https://www.youtube.com/watch?v=zAGVQLHvwOY",//joker
    "https://www.youtube.com/watch?v=V6X5ti4YlG8",//shrek 2
    "https://www.youtube.com/watch?v=SbXIj2T-_uk",//cars
    "https://www.youtube.com/watch?v=LoebZZ8K5N0",//the revenant
    "https://www.youtube.com/watch?v=CewglxElBK0",//step brothers
    "https://www.youtube.com/watch?v=CGbgaHoapFM",//monsters inc
    "https://www.youtube.com/watch?v=5UnjrG_N8hU",//revenge of the sith
    "https://www.youtube.com/watch?v=23eYIFi4gNw",//broken law
    "https://www.youtube.com/watch?v=6OaJCEIBU4w",// the field
    "https://www.youtube.com/watch?v=8ugaeA-nMTc",// iron man
    "https://www.youtube.com/watch?v=KgyGAxJhECU",// lassie
    "https://www.youtube.com/watch?v=o3dbeI0BU1k"];//scooby doo

function displayTrailer(index) {
    window.open(trailer[index]);
}




$totalPrice = 5;

function incrementTicketNo() {
    document.getElementById('ticketAmount').stepUp();
    document.getElementById('adultsAmount').max = document.getElementById('ticketAmount').value - document.getElementById('kidsAmount').value;
    document.getElementById('kidsAmount').max = document.getElementById('ticketAmount').value - document.getElementById('adultsAmount').value;
}
function decrementTicketNo() {
    document.getElementById('ticketAmount').stepDown();
    document.getElementById('adultsAmount').max = document.getElementById('ticketAmount').value - document.getElementById('kidsAmount').value;
    document.getElementById('kidsAmount').max = document.getElementById('ticketAmount').value - document.getElementById('adultsAmount').value;
}


function incrementAdults() {
    document.getElementById('adultsAmount').stepUp();
    document.getElementById('kidsAmount').max = document.getElementById('ticketAmount').value - document.getElementById('adultsAmount').value;
    totalPrice = (document.getElementById('kidsAmount').value * 5) + (document.getElementById('adultsAmount').value * 8);
    $('.totalCost').each(function () { $(this).text(totalPrice); })
}
function decrementAdults() {
    document.getElementById('adultsAmount').stepDown();
    document.getElementById('kidsAmount').max = document.getElementById('ticketAmount').value - document.getElementById('adultsAmount').value;
    totalPrice = (document.getElementById('kidsAmount').value * 5) + (document.getElementById('adultsAmount').value * 8);
    $('.totalCost').each(function () { $(this).text(totalPrice); })
}


function incrementKids() {
    document.getElementById('kidsAmount').stepUp();
    document.getElementById('adultsAmount').max = document.getElementById('ticketAmount').value - document.getElementById('kidsAmount').value;
    totalPrice = (document.getElementById('kidsAmount').value * 5) + (document.getElementById('adultsAmount').value * 8);
    $('.totalCost').each(function () { $(this).text(totalPrice); })
}
function decrementKids() {
    document.getElementById('kidsAmount').stepDown();
    document.getElementById('adultsAmount').max = document.getElementById('ticketAmount').value - document.getElementById('kidsAmount').value;
    totalPrice = (document.getElementById('kidsAmount').value * 5) + (document.getElementById('adultsAmount').value * 8);
    $('.totalCost').each(function () { $(this).text(totalPrice); })
}



function switchDivs() {
    if (parseInt(document.getElementById('adultsAmount').value) + parseInt(document.getElementById('kidsAmount').value) == parseInt(document.getElementById('ticketAmount').value)) {
        $("#ticketForm").fadeOut(500, function () { $("#customerForm").fadeIn(500); });
        document.getElementById('ticketsSelected').innerHTML = document.getElementById('ticketAmount').value;
        document.getElementById('adultsSelected').innerHTML = document.getElementById('adultsAmount').value;
        document.getElementById('kidsSelected').innerHTML = document.getElementById('kidsAmount').value;


        console.log(document.getElementById('varAmount').value);

        document.getElementById('varAmount').value = document.getElementById('ticketAmount').value;

        console.log(document.getElementById('varAmount').value);
        console.log(document.getElementById('ticketAmount').value);



        console.log(totalPrice);

        document.getElementById('varCost').value = totalPrice;

        console.log(document.getElementById('varCost').value);
    }
    else {

        alert('You wished to book ' + parseInt(document.getElementById('ticketAmount').value) + ' tickets. You allocated ' +
            (parseInt(document.getElementById('adultsAmount').value) + parseInt(document.getElementById('kidsAmount').value)) + ' of them. Apply the correct amount to either kids or adults.');
    }

}