<?php
    session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>


    <link rel="stylesheet" href="style.css">
    <link rel="shortcut icon" type="image/png" href="images/favicon.png" />

</head>

<body class="login">
    <?php
         $filmID = $_POST["filmID"];
         $name = $_POST["name"];
         $ageRating = $_POST["ageRating"];
         $length = $_POST["length"];
         $genre = $_POST["genre"];
         $description = $_POST["description"];
 
 
         include "config.php";
 



        $myQuery =  "UPDATE screening VALUES ($screeningID, $screenNo, '$time', $capacity, $price, $filmID)";
        echo $myQuery;



        $result = mysqli_query($conn, $myQuery);
        if($result) {
          echo 'OK record edited';
        } else {
          echo 'No edition made';
        }
        /* close connection */



 ?>

    <!-- BACK BUTTON -->
    <button onclick="goBack()">Go Back</button>
    <script>
    function goBack() {
        window.history.back();
    }
    </script>
    <!-- BACK BUTTON -->

    <!-- FOOTER INCLUDED FROM SEPARATE FILE -->
    <footer class="container-fluid text-center">
        <?php 
                mysqli_close($conn); //CLOSING DB DONNECTION AT THE END OF THE PAGE
                include 'footer.html'; 
            ?>
    </footer>

</body>

</html>