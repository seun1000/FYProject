<?php
    session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <title>ADMIN BACK-END</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>


    <link rel="stylesheet" href="style.css">
    <link rel="shortcut icon" type="image/png" href="images/favicon.png" />
    <script src="script.js"></script>
    <style>
    table th {
        background-color: #009879;
        color: #ffffff;
        text-align: left;
        font-weight: bold;
        padding: 15px 25px;
        text-align: center;
    }

    table td {
        padding: 15px 45px 15px 10px;
    }

    table tr {
        padding: 2px;
    }
    </style>
</head>

<body class="login">

    <?php

        include "config.php";

        // Check user login or not (THIS SITE ONLY ACCESSIBLE IF YOU LOGIN, GOING MANUALLY TO 'localhost/admin.php' WILL LEAD TO HOME PAGE IF NOT LOGGED IN)
        if($_SESSION['username'] != "manager"){
            header('Location: index.php');
        }

?>


    <!-- NAVIGATION BAR (TABS) -->
    <nav class="navbar navbar-inverse">

        <div class="container-fluid">

            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand"><img src="images/logo.png" width="30" height="25"></a> <!-- LOGO AT THE LEFT -->
            </div>

            <div class="collapse navbar-collapse" id="myNavbar">
                <!-- ALL TABS STARTING FROM LEFT -->
                <ul class="nav navbar-nav">
                    <li><a href="index.php">Monday</a></li>
                    <li><a href="tue.php">Tuesday</a></li>
                    <li><a href="wed.php">Wednesday</a></li>
                    <li><a href="thu.php">Thursday</a></li>
                    <li><a href="fri.php">Friday</a></li>
                    <li><a href="sat.php">Saturday</a></li>
                    <li><a href="sun.php">Sunday</a></li>
                </ul>
                <!-- ALL TABS STARTING FROM RIGHT -->
                <ul class="nav navbar-nav navbar-right">

                    <?php 
                        if(!isset($_SESSION['username'])){
                            echo '<li><a href="login.php"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>';
                        }
                        else if($_SESSION['username'] == "admin"){ 
                            echo '<li><a href="admin.php"><span class="glyphicon glyphicon-log-in"></span> ADMIN PANEL</a></li>';
                            echo '<li><a href="logout.php">Logout</a></li>';
                        }
                        else if ($_SESSION['username'] == "manager"){
                            echo '<li class="active"><a href="manager.php"><span class="glyphicon glyphicon-log-in"></span> MANAGER PANEL</a></li>';
                            echo '<li><a href="logout.php">Logout</a></li>';
                        }
                        else {
                            echo '<li><a href="account.php"><span class="glyphicon glyphicon-log-in"></span> Manage Account (' .$_SESSION['username']. ')</a></li>';
                            echo '<li><a href="logout.php">Logout</a></li>';
                        }
                    ?>

                </ul>
            </div>

        </div>

    </nav>






    <form method='post' action="">
        <input type="submit" value="Logout" name="but_logout">
    </form>


    <div class="container text-center">
        <!-- EDITING SCREENS FROM PARTICULAR DAY -->



        <br><br>


        <div class="row">
            <h3>Edit Screening:</h3><br>
            <h4>Select from Screen 1 to 4 </h4>
            <form action="editNewScreening.php" method="post">
                <label id="first"> Screening ID:</label><br />
                <input type="text" name="screeningID"><br />

                <label id="first">Screen Number:</label><br />
                <input type="text" name="screenNo"><br />

                <label id="first">Time:</label><br />
                <input type="text" name="time"><br />

                <label id="first">Date:</label><br />
                <input type="text" name="date"><br />

                <label id="first"> Capacity:</label><br />
                <input type="text" name="capacity"><br />

                <label id="first">Price:</label><br />
                <input type="text" name="price"><br />

                <label id="first">Film ID:</label><br />
                <input type="text" name="filmID"><br />

                <button type="submit" name="edit">edit</button>
            </form>




        </div>
        <div class="row">


        </div>

    </div><br>




    <!-- FOOTER INCLUDED FROM SEPARATE FILE -->
    <footer class="container-fluid text-center">
        <?php 
                mysqli_close($conn); //CLOSING DB DONNECTION AT THE END OF THE PAGE
                include 'footer.html'; 
            ?>
    </footer>

</body>

</html>