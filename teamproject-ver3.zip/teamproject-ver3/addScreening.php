<?php
    session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>


    <link rel="stylesheet" href="style.css">
    <link rel="shortcut icon" type="image/png" href="images/favicon.png" />

</head>

<body class="login">
    <?php
        $screeningID = $_POST["screeningID"];
        $screenNo = $_POST["screenNo"];
        $time = $_POST["time"];
        $date = $_POST["date"];
        $capacity = $_POST["capacity"];
        $price = $_POST["price"];
        $filmID = $_POST["filmID"];


        include "config.php";



        $myQuery = "INSERT INTO screening VALUES ($screeningID, $screenNo, '$time', $capacity, $price, $filmID)";
        echo $myQuery;
    
        $result = mysqli_query($conn, $myQuery);
        if($result) {
            echo 'OK record inserted';
        } else {
            echo 'No insertion made';
        }

    ?>

    <!-- BACK BUTTON -->
    <button onclick="goBack()">Go Back</button>
    <script>
    function goBack() {
        window.history.back();
    }
    </script>
    <!-- BACK BUTTON -->

    <!-- FOOTER INCLUDED FROM SEPARATE FILE -->
    <footer class="container-fluid text-center">
        <?php 
                mysqli_close($conn); //CLOSING DB DONNECTION AT THE END OF THE PAGE
                include 'footer.html'; 
            ?>
    </footer>

</body>

</html>