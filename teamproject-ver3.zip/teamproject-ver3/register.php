<?php
    session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <title>Register</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="style.css">
    <link rel="shortcut icon" type="image/png" href="images/favicon.png" />

</head>

<body class="login">

    <?php
        include "config.php";

        // when form submitted
        if(isset($_POST['regSubmit'])){
            $username = $conn -> real_escape_string(stripslashes(strip_tags($_POST["username"])));
            $pass = $conn -> real_escape_string(($_POST["password"]));

            $sql_query = "select count(*) as cntUser from credentials where username='".$username."'";
            $result = mysqli_query($conn,$sql_query);
            $row = mysqli_fetch_array($result);
            $count = $row['cntUser'];

            if($count > 0){
                echo "<script type='text/javascript'>alert('Username already taken. Try Again.');</script>";
            } else{
                $sql_insert = "INSERT INTO credentials VALUES ('$username','$pass')";
                mysqli_query($conn,$sql_insert);
                $_SESSION['username'] = $username;
                sleep(2);
                header('Location: account.php'); //for other users redirect to their account
            }

        }
                
    ?>


    <nav class="navbar navbar-inverse">

        <div class="container-fluid">

            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand"><img src="images/logo.png" width="30" height="25"></a>
            </div>

            <div class="collapse navbar-collapse" id="myNavbar">
                <ul class="nav navbar-nav">
                    <li><a href="index.php">Monday</a></li>
                    <li><a href="tue.php">Tuesday</a></li>
                    <li><a href="wed.php">Wednesday</a></li>
                    <li><a href="thu.php">Thursday</a></li>
                    <li><a href="fri.php">Friday</a></li>
                    <li><a href="sat.php">Saturday</a></li>
                    <li><a href="sun.php">Sunday</a></li>
                </ul>
                <ul class="nav navbar-nav navbar-right">

                    <?php 
                        if(!isset($_SESSION['username'])){
                            echo '<li><a href="login.php"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>';
                        }
                        else if($_SESSION['username'] == "admin"){ 
                            echo '<li><a href="admin.php"><span class="glyphicon glyphicon-log-in"></span> ADMIN PANEL</a></li>';
                            echo '<li><a href="logout.php">Logout</a></li>';
                        }
                        else if ($_SESSION['username'] == "manager"){
                            echo '<li class="active"><a href="manager.php"><span class="glyphicon glyphicon-log-in"></span> MANAGER PANEL</a></li>';
                            echo '<li><a href="logout.php">Logout</a></li>';
                        }
                        else {
                            echo '<li><a href="account.php"><span class="glyphicon glyphicon-log-in"></span> Manage Account (' .$_SESSION['username']. ')</a></li>';
                            echo '<li><a href="logout.php">Logout</a></li>';
                        }
                    ?>

                </ul>

            </div>

        </div>

    </nav>

    <div class="regWrapper">
        <h1>Sign Up</h1>

        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">

            <label>E-mail:</label>
            <br>
            <input name="username" type="email" placeholder="username@email.com" required>
            <br><br>

            <label>Password:</label>
            <br>
            <input name="password" type="password" placeholder="password" pattern=".{5,25}" required
                title="5 to 25 characters" required>
            <br><br>

            <input type="submit" value="Submit" id="regSubmit" name="regSubmit">
            <input type="reset" value="Reset">

        </form>

    </div>

    <!-- FOOTER INCLUDED FROM SEPARATE FILE -->
    <footer class="container-fluid text-center">
        <?php 
                mysqli_close($conn); //CLOSING DB DONNECTION AT THE END OF THE PAGE
                include 'footer.html'; 
            ?>
    </footer>

</body>

</html>