<?php
    session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <title>Book a ticket</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script> <!-- BOOTSTRAP STYLING -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <!-- BOOTSTRAP STYLING -->

    <link rel="stylesheet" href="style.css"> <!-- CSS file -->
    <link rel="shortcut icon" type="image/png" href="images/favicon.png" /> <!-- Favicon file -->
    <script src="script.js"></script>

</head>

<body>

    <!-- DATABASE CONNECTION IN CONFIG.PHP -->
    <?php
      include "config.php";
    ?>

    <!-- NAVIGATION BAR (TABS) -->
    <nav id="navbarid" class="navbar navbar-inverse">

        <div class="container-fluid">

            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand"><img src="images/logo.png" width="30" height="25"></a> <!-- LOGO AT THE LEFT -->
            </div>

            <div class="collapse navbar-collapse" id="myNavbar">
                <!-- ALL TABS STARTING FROM LEFT -->
                <ul class="nav navbar-nav">
                    <li><a href="index.php">Monday</a></li>
                    <li><a href="tue.php">Tuesday</a></li>
                    <li><a href="wed.php">Wednesday</a></li>
                    <li><a href="thu.php">Thursday</a></li>
                    <li><a href="fri.php">Friday</a></li>
                    <li><a href="sat.php">Saturday</a></li>
                    <li><a href="sun.php">Sunday</a></li>
                </ul>
                <!-- ALL TABS STARTING FROM RIGHT -->
                <ul class="nav navbar-nav navbar-right">

                    <?php 
                        if(!isset($_SESSION['username'])){
                            echo '<li><a href="login.php"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>';
                        }
                        else if($_SESSION['username'] == "admin"){ 
                            echo '<li><a href="admin.php"><span class="glyphicon glyphicon-log-in"></span> ADMIN PANEL</a></li>';
                            echo '<li><a href="logout.php">Logout</a></li>';
                        }
                        else if ($_SESSION['username'] == "manager"){
                            echo '<li class="active"><a href="manager.php"><span class="glyphicon glyphicon-log-in"></span> MANAGER PANEL</a></li>';
                            echo '<li><a href="logout.php">Logout</a></li>';
                        }
                        else {
                            echo '<li><a href="account.php"><span class="glyphicon glyphicon-log-in"></span> Manage Account (' .$_SESSION['username']. ')</a></li>';
                            echo '<li><a href="logout.php">Logout</a></li>';
                        }
                    ?>

                </ul>
            </div>

        </div>

    </nav>

    <div id="myCarousel" class="carousel slide" data-ride="carousel">

        <!-- Dot Indicators / each coresponds to one screen -->
        <ol class="carousel-indicators">
            <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
            <li data-target="#myCarousel" data-slide-to="1"></li>
            <li data-target="#myCarousel" data-slide-to="2"></li>
            <li data-target="#myCarousel" data-slide-to="3"></li>
            <li data-target="#myCarousel" data-slide-to="4"></li>
        </ol>


        <!-- Wrapper for slides (images) / slides are coressponding to featured movie of the week? -->
        <div class="carousel-inner" role="listbox">

            <!-- MONDAY -->
            <div class="item">
                <img src="images/horror1.jpg" alt="Image for Monday">
            </div>
            <!-- TUESDAY -->
            <div class="item">
                <img src="images/horror2.jpg" alt="Image for Tuesday">
            </div>
            <!-- WEDNESDAY -->
            <div class="item">
                <img src="images/horror3.jpg" alt="Image for Wednesday">
            </div>
            <!-- THURSDAY -->
            <div class="item">
                <img src="images/horror4.jpg" alt="Image for Thursday">
            </div>
            <!-- FRIDAY -->
            <div class="item active">
                <img src="images/horror5.jpg" alt="Image for Friday">
            </div>

        </div>


        <!-- Left and right arrows for sliding screens -->
        <a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
            <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
        </a>
        <a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
            <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
        </a>

    </div>

    <!-- ALL THE CONTENT IN THE MIDDLE -->
    <div class="container-main">
        <div class="container-hello">
            <?php // Check if the form is submitted 
                if(isset($_POST['makeBookButton'])){

                    $screeningToBook = $_POST['var'];
                    $cusName = $_POST['customerName'];
                    $loggedUser = $_SESSION["username"];
                    $costBook = $_POST['varCost'];
                    $amountBook = $_POST["varAmount"];
                    $bookingID = rand(1, 9999);

                    $sqlStatm = "SELECT count(*) as userCount FROM customer WHERE username = '$loggedUser'";
                    $result = mysqli_query($conn, $sqlStatm);
                    $row = mysqli_fetch_array($result);
                    $count = $row['userCount'];
                    if ($count == 0){
                        $sqlStatm = "INSERT INTO customer VALUES ('$cusName', '$loggedUser')";
                        mysqli_query($conn, $sqlStatm);
                    }
                    

                    $sqlStatm = "INSERT INTO booking VALUES ($bookingID, $amountBook, $costBook, '$loggedUser', $screeningToBook)";
                    mysqli_query($conn, $sqlStatm);

                    $sqlStatm = "UPDATE screening SET capacity = capacity - $amountBook WHERE screeningID = $screeningToBook";
                    mysqli_query($conn, $sqlStatm);

                    echo '<h1>Booking Complete.</h2><br><br>';
                    echo '<h2>Clich <a href="account.php"><u><b>here</b></u></a> to view your reservations</h2>';

                }

                else if ( isset( $_POST['submit-btn'] ) && isset($_SESSION['username']) ) {
                    // retrieve the form data by using the element's name attributes value as key 
                    $screening = $_POST["movie"];

                    $sqlStatm = "SELECT name, capacity, time, date, ageRating FROM screening, film WHERE screeningID = $screening AND screening.filmID = film.filmID";
                    $result = mysqli_query($conn, $sqlStatm);
                    $row = mysqli_fetch_array($result);

                    
                    ?>

            <h3>Making booking as: <b><?php echo $_SESSION['username']; ?></b></h3>
            <h2>Selected movie:
                <b><?php echo $row["name"] ?></b>
            </h2>
            <h3>When:
                <b><?php echo date('H:i \o\n ', strtotime($row["time"])) . date('l, dS', strtotime($row["date"])); ?></b>
            </h3>
            <h4>Seats available:
                <b><?php echo $row["capacity"]; ?></b>
            </h4>

            <br>


            <br>


            <form id="ticketForm">

                <label for="ticketAmount">
                    <h4>Number of tickets you wish to book (max
                        <?php echo $row["capacity"] > 10 ? '10' : $row["capacity"]; ?>): </h4>
                </label>
                <input type="number" id="ticketAmount" name="ticketAmount" min="1"
                    max="<?php echo ($row["capacity"] > 10) ? '10' : $row["capacity"]; ?>" value="1" readonly>
                <input type="button" onclick="incrementTicketNo()" value=" + "></input>
                <input type="button" onclick="decrementTicketNo()" value=" - "></input>

                <br><br><br>


                <label for="adults">
                    <h4>Adults (&euro;8): </h4>
                </label>
                <input type="number" id="adultsAmount" name="adultsAmount" min="0" max="0" value="0" readonly>
                <input type="button" onclick="incrementAdults()" id="adultIncBtn" value="+"></input>
                <input type="button" onclick="decrementAdults()" id="adultDecBtn" value="-"></input>
                <br>
                <label for="kids">
                    <h4>Kids (&euro;5): </h4>
                </label>
                <input type="number" id="kidsAmount" name="kidsAmount" min="0" max="0" value="0" readonly>
                <input type="button" onclick="incrementKids()" id="kidIncBtn" value="+"></input>
                <input type="button" onclick="decrementKids()" id="kidDecBtn" value="-"></input>


                <h2>Total cost: &euro;<span class="totalCost">0</span></h2>

                <input type="button" onclick="switchDivs()" value="Submit"></input>
            </form>





            <form id="customerForm" action="book.php" method="post">

                <h2>Total cost: &euro;<span class="totalCost">0</span></h2>
                <h2>Selected tickets: <b><span id="ticketsSelected"></span></b> (<span id="adultsSelected"></span>
                    adults and <span id="kidsSelected"></span> kids)</h2>
                <label for="customerName">
                    <h4>Enter name to complete booking: </h4>
                </label>

                <input type='hidden' name='varCost' id='varCost' value=''>
                <input type='hidden' name='varAmount' id='varAmount' value=''>
                <input type='hidden' name='var' value='<?php echo $screening;?>' />

                <input type="text" id="customerName" name="customerName" maxlength="40" placeholder="name" required>
                <br>
                <input type="submit" value="Make Booking" name="makeBookButton"></input>

            </form>



            <?php
                    
                }
                else if(!isset($_SESSION['username']) && isset($_POST['submit-btn'])){
                    echo "<br><br><br><h1>You need to be logged in.</h1><br>";
                }
                else{
                    echo "<br><br><br><h1>Error. Go back to schedules and pick a movie to book.</h1><br>";
                }
            ?>


        </div>
    </div>



    <!-- FOOTER INCLUDED FROM SEPARATE FILE -->
    <footer class="container-fluid text-center">
        <?php 
            mysqli_close($conn); //CLOSING DB DONNECTION AT THE END OF THE PAGE
            include 'footer.html'; 
        ?>
    </footer>

</body>

</html>